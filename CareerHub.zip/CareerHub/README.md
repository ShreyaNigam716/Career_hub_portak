# CareerHub: Online Job Search and Recruitment

![Java](https://img.shields.io/badge/Java-17-orange)
![Swing](https://img.shields.io/badge/UI-Java%20Swing-blue)
![MySQL](https://img.shields.io/badge/Database-MySQL%208-00758F)
![JDBC](https://img.shields.io/badge/Connectivity-JDBC-green)
![License](https://img.shields.io/badge/License-MIT-lightgrey)

A Java desktop application that brings job seekers, recruiters and an administrator together on one shared MySQL database. Job seekers build a profile, search and apply for jobs and track their applications. Recruiters post jobs and shortlist or reject applicants. The admin keeps the platform clean by managing users and removing fake or old posts.

Built as the Project Based Learning project for **OOPs using Java (24B15CS215)**, B.Tech. III Semester, Jaypee Institute of Information Technology.

---

## Features

### Job Seeker
- Register, log in and edit profile (name, phone, city, skills)
- Upload a resume (PDF, DOC or DOCX, up to 2 MB) and open it again later
- Search open jobs by title, city and minimum salary
- Apply to jobs (one application per job)
- Track every application with colour coded status: **Applied, Seen, Shortlisted, Rejected**

### Recruiter
- Post and edit jobs, close or reopen them
- See how many people applied to each job
- View applicants with their details and resume
- Application automatically becomes **Seen** when opened, then **Shortlist** or **Reject**

### Admin
- View all users, filter by role, delete users (their jobs and applications are deleted too)
- Remove fake posts one by one, or remove every post older than N days
- Summary report of users, jobs and applications

### Behind the scenes
- Passwords stored as **salted SHA-256 hashes**, never as plain text
- All SQL uses `PreparedStatement` (protection against SQL injection)
- A **database trigger** blocks applications to jobs that are not open
- A **database view** powers the admin report
- Indexes on job title and city for faster search
- Clear error messages through six custom exceptions

---

## Tech Stack

| Purpose | Tool |
| --- | --- |
| Language | Java (JDK 17) |
| User interface | Java Swing |
| Database | MySQL 8 |
| Connectivity | JDBC (MySQL Connector/J) |
| IDE | Eclipse |

---

## Project Structure

```
CareerHub/
├── database/
│   ├── schema.sql            # tables, indexes, trigger, view
│   └── sample_data.sql       # sample job posts
├── docs/
│   └── screenshots/          # images used in this README
├── lib/                      # put mysql-connector-j jar here (not committed)
└── src/careerhub/
    ├── app/        Main, SeedData
    ├── db/         DBConnection
    ├── model/      User (abstract), JobSeeker, Recruiter, Admin, Resume, Job, Application, Applicant
    ├── dao/        UserDAO, JobDAO, ApplicationDAO, ReportDAO (interfaces) + Impl classes
    ├── exception/  six custom exceptions
    ├── util/       PasswordUtil, Validator, ResumeManager
    └── ui/         LoginFrame, RegisterFrame, BaseDashboard, three dashboards and their panels, Theme
```

---

## OOP Concepts Used

| Concept | Where it is used |
| --- | --- |
| Classes and Objects | `User`, `Job`, `Application`, `Resume`, `Applicant` |
| Inheritance | `JobSeeker`, `Recruiter`, `Admin` extend `User`; `Applicant` extends `Application`; dashboards extend `BaseDashboard` |
| Polymorphism | `user.showDashboard()` opens a different screen for each role |
| Encapsulation | Private fields with getters and setters in all model classes |
| Abstraction | Abstract classes `User` and `BaseDashboard`; DAO interfaces |
| Exception Handling | Wrong login, empty fields, duplicate accounts, repeated applications, database errors |
| Collections | `List` and `ArrayList` for jobs, applications, applicants and users |
| File I/O | `ResumeManager` copies resumes with byte streams; `Resume` checks files |
| Packages | `app`, `db`, `model`, `dao`, `exception`, `util`, `ui` |

---

## Database Design

Three tables, linked by foreign keys with `ON DELETE CASCADE`.

| Table | Purpose |
| --- | --- |
| `users` | All accounts. `role` is `JOB_SEEKER`, `RECRUITER` or `ADMIN` |
| `jobs` | Job posts. `status` is `OPEN`, `CLOSED` or `REMOVED` |
| `applications` | One row per seeker per job. `status` is `APPLIED`, `SEEN`, `SHORTLISTED` or `REJECTED` |

Extra objects: trigger `trg_block_closed_job_apply`, view `v_admin_summary`, indexes `idx_jobs_title` and `idx_jobs_city`.

---

## Getting Started

### Prerequisites
- JDK 17
- MySQL Server 8 and MySQL Workbench
- Eclipse IDE (or any Java IDE)
- [MySQL Connector/J](https://dev.mysql.com/downloads/connector/j/) (choose *Platform Independent*)

### Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/ShreyaNigam716/CareerHub-Job-Portal.git
   ```
2. **Create the database.** Open `database/schema.sql` in MySQL Workbench and run it. Then run `database/sample_data.sql` after step 5.
3. **Import into Eclipse.** File → Import → Existing Projects into Workspace, and select the cloned folder.
4. **Add the JDBC driver.** Copy `mysql-connector-j-8.x.x.jar` into the `lib/` folder, then right-click the project → Build Path → Configure Build Path → Libraries → Add JARs.
5. **Set your MySQL password** in `src/careerhub/db/DBConnection.java` (`PASSWORD`). Do not commit your real password.
6. **Create demo accounts.** Run `careerhub.app.SeedData` once.
7. **Start the application.** Run `careerhub.app.Main`.
8. Optional: now run `database/sample_data.sql` to add sample jobs.

### Demo accounts

| Role | Email | Password |
| --- | --- | --- |
| Admin | admin@careerhub.com | admin123 |
| Recruiter | rahul@techcorp.com | rec12345 |
| Job Seeker | seeker@demo.com | seeker123 |

---

## Screenshots

| Login | Job Search |
| --- | --- |
| ![Login](docs/screenshots/login.png) | ![Search](docs/screenshots/search-jobs.png) |

| My Applications | Applicants (Recruiter) |
| --- | --- |
| ![Applications](docs/screenshots/my-applications.png) | ![Applicants](docs/screenshots/applicants.png) |

| Manage Job Posts (Admin) | Reports (Admin) |
| --- | --- |
| ![Posts](docs/screenshots/manage-posts.png) | ![Reports](docs/screenshots/reports.png) |

---

## Future Scope

- Web and mobile versions
- Resume to job matching
- E-mail alerts for status changes
- Password reset, bcrypt hashing and cloud resume storage
- Pagination, connection pooling and unit tests

---

## Team

| Name | Roll No. |
| --- | --- |
| Prakhar Lal | 2501030059 |
| Shreya Nigam | 2501030076 |
| Saneh | 2501030082 |

Submitted to: Silki Karaliya
Jaypee Institute of Information Technology, Department of Computer Science Engineering, Batch B11, Academic Year 2026-2027.

## License

Released under the [MIT License](LICENSE).
