-- CareerHub database schema (MySQL 8)
CREATE DATABASE IF NOT EXISTS careerhub;
USE careerhub;

CREATE TABLE users (
    user_id       INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(120) NOT NULL,
    role          ENUM('JOB_SEEKER','RECRUITER','ADMIN') NOT NULL,
    phone         VARCHAR(15),
    city          VARCHAR(50),
    skills        VARCHAR(255),
    resume_path   VARCHAR(255),
    company_name  VARCHAR(100),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE jobs (
    job_id       INT AUTO_INCREMENT PRIMARY KEY,
    recruiter_id INT NOT NULL,
    title        VARCHAR(100) NOT NULL,
    description  TEXT,
    city         VARCHAR(50),
    salary       DECIMAL(10,2),
    status       ENUM('OPEN','CLOSED','REMOVED') DEFAULT 'OPEN',
    posted_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recruiter_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE applications (
    application_id INT AUTO_INCREMENT PRIMARY KEY,
    job_id         INT NOT NULL,
    seeker_id      INT NOT NULL,
    status         ENUM('APPLIED','SEEN','SHORTLISTED','REJECTED') DEFAULT 'APPLIED',
    applied_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (job_id, seeker_id),
    FOREIGN KEY (job_id)    REFERENCES jobs(job_id)   ON DELETE CASCADE,
    FOREIGN KEY (seeker_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_jobs_title ON jobs(title);
CREATE INDEX idx_jobs_city  ON jobs(city);

-- Blocks applications to jobs that are not OPEN
DELIMITER //
CREATE TRIGGER trg_block_closed_job_apply
BEFORE INSERT ON applications
FOR EACH ROW
BEGIN
    DECLARE job_state VARCHAR(10);
    SELECT status INTO job_state FROM jobs WHERE job_id = NEW.job_id;
    IF job_state <> 'OPEN' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'This job is no longer open for applications';
    END IF;
END//
DELIMITER ;

-- Summary used by the Admin Reports tab
CREATE OR REPLACE VIEW v_admin_summary AS
SELECT 'Job Seekers' AS label, COUNT(*) AS total FROM users WHERE role = 'JOB_SEEKER'
UNION ALL SELECT 'Recruiters',                  COUNT(*) FROM users WHERE role = 'RECRUITER'
UNION ALL SELECT 'Open jobs',                   COUNT(*) FROM jobs WHERE status = 'OPEN'
UNION ALL SELECT 'Closed jobs',                 COUNT(*) FROM jobs WHERE status = 'CLOSED'
UNION ALL SELECT 'Removed jobs',                COUNT(*) FROM jobs WHERE status = 'REMOVED'
UNION ALL SELECT 'Total applications',          COUNT(*) FROM applications
UNION ALL SELECT 'Applications - Applied',      COUNT(*) FROM applications WHERE status = 'APPLIED'
UNION ALL SELECT 'Applications - Seen',         COUNT(*) FROM applications WHERE status = 'SEEN'
UNION ALL SELECT 'Applications - Shortlisted',  COUNT(*) FROM applications WHERE status = 'SHORTLISTED'
UNION ALL SELECT 'Applications - Rejected',     COUNT(*) FROM applications WHERE status = 'REJECTED';
