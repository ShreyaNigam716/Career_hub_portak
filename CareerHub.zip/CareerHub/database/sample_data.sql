-- Sample jobs. Run careerhub.app.SeedData first so rahul@techcorp.com exists.
USE careerhub;

INSERT INTO jobs (recruiter_id, title, description, city, salary, status) VALUES
((SELECT user_id FROM users WHERE email = 'rahul@techcorp.com'),
 'Java Developer',
 'Build and maintain backend services using Java, JDBC and MySQL. Freshers with strong OOP basics are welcome.',
 'Noida', 600000, 'OPEN'),
((SELECT user_id FROM users WHERE email = 'rahul@techcorp.com'),
 'Frontend Developer',
 'Create responsive interfaces with React and Tailwind CSS. Good eye for UI/UX needed.',
 'Delhi', 550000, 'OPEN'),
((SELECT user_id FROM users WHERE email = 'rahul@techcorp.com'),
 'Database Intern',
 'Assist the data team with MySQL schema design, queries and reports. 6 month internship.',
 'Ghaziabad', 240000, 'OPEN'),
((SELECT user_id FROM users WHERE email = 'rahul@techcorp.com'),
 'Graphic Designer',
 'Design social media posts, catalogues and presentation decks using Canva.',
 'Noida', 360000, 'OPEN'),
((SELECT user_id FROM users WHERE email = 'rahul@techcorp.com'),
 'Old Support Executive',
 'This post is closed and must NOT appear in search results.',
 'Noida', 300000, 'CLOSED');
