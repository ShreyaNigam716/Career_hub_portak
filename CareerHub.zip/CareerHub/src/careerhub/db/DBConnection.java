package careerhub.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import careerhub.exception.DatabaseException;

public class DBConnection {

    private static final String URL =
        "jdbc:mysql://localhost:3306/careerhub?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";   // <-- change this (never commit your real password)

    // Utility class: no objects needed
    private DBConnection() {
    }

    public static Connection getConnection() throws DatabaseException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new DatabaseException("Could not connect to the database: " + e.getMessage(), e);
        }
    }
}
