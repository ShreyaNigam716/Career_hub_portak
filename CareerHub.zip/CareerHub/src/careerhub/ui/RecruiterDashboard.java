package careerhub.ui;

import java.awt.BorderLayout;

import javax.swing.JTabbedPane;

import careerhub.model.Recruiter;

public class RecruiterDashboard extends BaseDashboard {

    public RecruiterDashboard(Recruiter recruiter) {
        super(recruiter, "Recruiter");

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.BUTTON_FONT);

        MyJobsPanel jobsPanel = new MyJobsPanel(recruiter);
        ApplicantsPanel applicantsPanel = new ApplicantsPanel(recruiter);

        tabs.addTab("My Jobs", jobsPanel);
        tabs.addTab("Applicants", applicantsPanel);

        // Fresh data every time a tab is opened
        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == jobsPanel) {
                jobsPanel.loadJobs();
            } else if (tabs.getSelectedComponent() == applicantsPanel) {
                applicantsPanel.loadJobs();
            }
        });

        add(tabs, BorderLayout.CENTER);
    }
}
