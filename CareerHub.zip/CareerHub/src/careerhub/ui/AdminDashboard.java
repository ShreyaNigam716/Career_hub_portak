package careerhub.ui;

import java.awt.BorderLayout;

import javax.swing.JTabbedPane;

import careerhub.model.Admin;

public class AdminDashboard extends BaseDashboard {

    public AdminDashboard(Admin admin) {
        super(admin, "Admin");

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.BUTTON_FONT);

        ManageUsersPanel usersPanel = new ManageUsersPanel();
        ManageJobsPanel jobsPanel = new ManageJobsPanel();
        ReportsPanel reportsPanel = new ReportsPanel();

        tabs.addTab("Manage Users", usersPanel);
        tabs.addTab("Manage Job Posts", jobsPanel);
        tabs.addTab("Reports", reportsPanel);

        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == usersPanel) {
                usersPanel.loadUsers();
            } else if (tabs.getSelectedComponent() == jobsPanel) {
                jobsPanel.loadJobs();
            } else if (tabs.getSelectedComponent() == reportsPanel) {
                reportsPanel.loadReport();
            }
        });

        add(tabs, BorderLayout.CENTER);
    }
}
