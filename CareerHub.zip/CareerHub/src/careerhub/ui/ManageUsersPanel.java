package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.UserDAO;
import careerhub.dao.UserDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.model.User;

public class ManageUsersPanel extends JPanel {

    private final UserDAO userDAO = new UserDAOImpl();

    private DefaultTableModel tableModel;
    private JTable table;
    private JComboBox<String> roleCombo;
    private JLabel countLabel;

    private List<User> allUsers = new ArrayList<>();
    private List<User> shown = new ArrayList<>();     // same order as table rows

    public ManageUsersPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        // ---- top bar ----
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        top.setBackground(Theme.CARD);

        roleCombo = new JComboBox<>(new String[] {"All", "JOB_SEEKER", "RECRUITER", "ADMIN"});
        roleCombo.setFont(Theme.BODY_FONT);
        roleCombo.addActionListener(e -> applyFilter());

        JButton refreshBtn = Theme.linkButton("Refresh");
        refreshBtn.addActionListener(e -> loadUsers());
        countLabel = Theme.mutedLabel("");

        top.add(Theme.label("Show role:"));
        top.add(roleCombo);
        top.add(refreshBtn);
        top.add(countLabel);

        // ---- table ----
        tableModel = new DefaultTableModel(
                new String[] {"ID", "Name", "Email", "Role", "City", "Phone"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);

        // ---- bottom ----
        JButton deleteBtn = Theme.primaryButton("Delete Selected User");
        deleteBtn.setBackground(Theme.DANGER);
        deleteBtn.addActionListener(e -> deleteSelected());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bottom.setOpaque(false);
        bottom.add(deleteBtn);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        loadUsers();
    }

    public void loadUsers() {
        try {
            allUsers = userDAO.getAllUsers();
            applyFilter();
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void applyFilter() {
        String role = (String) roleCombo.getSelectedItem();
        shown = new ArrayList<>();
        tableModel.setRowCount(0);

        for (User u : allUsers) {
            if ("All".equals(role) || u.getRole().equals(role)) {
                shown.add(u);
                tableModel.addRow(new Object[] {
                        u.getUserId(), u.getFullName(), u.getEmail(),
                        u.getRole(), u.getCity(), u.getPhone()
                });
            }
        }
        countLabel.setText(shown.size() + " user(s)");
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select a user first.");
            return;
        }
        User user = shown.get(row);

        if ("ADMIN".equals(user.getRole())) {
            Theme.showWarning(this, "Admin accounts cannot be deleted.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(this,
                "Delete " + user.getFullName() + " (" + user.getEmail() + ")?\n"
                + "All their jobs and applications will also be deleted.",
                "Confirm delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            userDAO.deleteUser(user.getUserId());
            loadUsers();
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
