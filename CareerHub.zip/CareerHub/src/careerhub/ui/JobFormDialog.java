package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.Window;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import careerhub.dao.JobDAO;
import careerhub.dao.JobDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.exception.InvalidInputException;
import careerhub.model.Job;
import careerhub.model.Recruiter;
import careerhub.util.Validator;

// One pop-up used for both posting a new job and editing an existing one
public class JobFormDialog extends JDialog {

    private final Recruiter recruiter;
    private final Job existingJob;            // null means "post a new job"
    private final JobDAO jobDAO = new JobDAOImpl();
    private boolean saved = false;

    private JTextField titleField, cityField, salaryField;
    private JTextArea descArea;

    public JobFormDialog(Window owner, Recruiter recruiter, Job existingJob) {
        super(owner, existingJob == null ? "Post a New Job" : "Edit Job",
                Dialog.ModalityType.APPLICATION_MODAL);
        this.recruiter = recruiter;
        this.existingJob = existingJob;

        setSize(500, 480);
        setLocationRelativeTo(owner);
        buildUI();
    }

    public boolean isSaved() {
        return saved;
    }

    private void buildUI() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(new EmptyBorder(24, 28, 24, 28));

        titleField = new JTextField(22);
        cityField = new JTextField(22);
        salaryField = new JTextField(22);
        descArea = new JTextArea(6, 22);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setFont(Theme.BODY_FONT);
        descArea.setBorder(new EmptyBorder(6, 8, 6, 8));
        Theme.styleField(titleField);
        Theme.styleField(cityField);
        Theme.styleField(salaryField);

        if (existingJob != null) {
            titleField.setText(existingJob.getTitle());
            cityField.setText(existingJob.getCity());
            salaryField.setText(String.valueOf((long) existingJob.getSalary()));
            descArea.setText(existingJob.getDescription());
        }

        JButton saveBtn = Theme.primaryButton(existingJob == null ? "Post Job" : "Save Changes");
        saveBtn.addActionListener(e -> save());
        JButton cancelBtn = Theme.linkButton("Cancel");
        cancelBtn.addActionListener(e -> dispose());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(cancelBtn);
        buttons.add(saveBtn);

        Theme.addRow(card, 0, "Job title", titleField);
        Theme.addRow(card, 1, "City", cityField);
        Theme.addRow(card, 2, "Salary (Rs./year)", salaryField);
        Theme.addRow(card, 3, "Description", new JScrollPane(descArea));
        Theme.addFull(card, 4, buttons, 20);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BACKGROUND);
        root.add(card, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void save() {
        try {
            String title = titleField.getText().trim();
            String city = cityField.getText().trim();
            String salaryText = salaryField.getText().trim();
            String desc = descArea.getText().trim();

            Validator.checkNotEmpty("Job title", title);
            Validator.checkNotEmpty("City", city);
            Validator.checkNotEmpty("Salary", salaryText);
            Validator.checkNotEmpty("Description", desc);

            double salary;
            try {
                salary = Double.parseDouble(salaryText);
            } catch (NumberFormatException ex) {
                throw new InvalidInputException("Salary must be a number");
            }
            if (salary <= 0) {
                throw new InvalidInputException("Salary must be greater than 0");
            }

            if (existingJob == null) {
                jobDAO.postJob(new Job(0, recruiter.getUserId(), title, desc,
                        city, salary, "OPEN", null));
            } else {
                existingJob.setTitle(title);
                existingJob.setCity(city);
                existingJob.setSalary(salary);
                existingJob.setDescription(desc);
                jobDAO.updateJob(existingJob);
            }

            saved = true;
            dispose();

        } catch (InvalidInputException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
