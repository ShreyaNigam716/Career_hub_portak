package careerhub.ui;

import java.awt.BorderLayout;

import javax.swing.JTabbedPane;

import careerhub.model.JobSeeker;

public class JobSeekerDashboard extends BaseDashboard {

    public JobSeekerDashboard(JobSeeker seeker) {
        super(seeker, "Job Seeker");

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.BUTTON_FONT);

        MyApplicationsPanel applicationsPanel = new MyApplicationsPanel(seeker);

        tabs.addTab("Search Jobs", new SearchJobsPanel(seeker));
        tabs.addTab("My Applications", applicationsPanel);
        tabs.addTab("My Profile", new ProfilePanel(seeker));

        // Reload the list every time the tab is opened
        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == applicationsPanel) {
                applicationsPanel.loadApplications();
            }
        });

        add(tabs, BorderLayout.CENTER);
    }
}
