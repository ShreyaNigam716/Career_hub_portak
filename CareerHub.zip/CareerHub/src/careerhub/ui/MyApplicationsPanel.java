package careerhub.ui;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.ApplicationDAO;
import careerhub.dao.ApplicationDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.model.Application;
import careerhub.model.JobSeeker;

public class MyApplicationsPanel extends JPanel {

    private final JobSeeker seeker;
    private final ApplicationDAO applicationDAO = new ApplicationDAOImpl();
    private DefaultTableModel tableModel;
    private JLabel summaryLabel;

    public MyApplicationsPanel(JobSeeker seeker) {
        this.seeker = seeker;
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        // top bar
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        summaryLabel = Theme.mutedLabel("");
        JButton refreshBtn = Theme.primaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadApplications());
        top.add(summaryLabel, BorderLayout.WEST);
        top.add(refreshBtn, BorderLayout.EAST);

        // table
        tableModel = new DefaultTableModel(
                new String[] {"Job Title", "Company", "Applied On", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);
        Theme.styleTable(table);
        table.getColumnModel().getColumn(3).setCellRenderer(new StatusCellRenderer());

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadApplications();
    }

    public void loadApplications() {
        try {
            List<Application> list = applicationDAO.getApplicationsBySeeker(seeker.getUserId());
            tableModel.setRowCount(0);
            for (Application a : list) {
                tableModel.addRow(new Object[] {
                        a.getJobTitle(),
                        a.getCompanyName(),
                        Theme.dateOnly(a.getAppliedAt()),
                        a.getStatus()
                });
            }
            summaryLabel.setText("You have applied to " + list.size() + " job(s)");
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
