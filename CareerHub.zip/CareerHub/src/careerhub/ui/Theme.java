package careerhub.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;

// Central place for colours, fonts and small UI helpers
public class Theme {

    public static final Color PRIMARY    = new Color(37, 99, 235);
    public static final Color BACKGROUND = new Color(243, 244, 246);
    public static final Color CARD       = Color.WHITE;
    public static final Color TEXT       = new Color(31, 41, 55);
    public static final Color MUTED      = new Color(107, 114, 128);
    public static final Color SUCCESS    = new Color(22, 163, 74);
    public static final Color DANGER     = new Color(220, 38, 38);
    public static final Color WARNING    = new Color(217, 119, 6);

    public static final Font TITLE_FONT   = new Font("SansSerif", Font.BOLD, 26);
    public static final Font HEADING_FONT = new Font("SansSerif", Font.BOLD, 16);
    public static final Font BUTTON_FONT  = new Font("SansSerif", Font.BOLD, 14);
    public static final Font BODY_FONT    = new Font("SansSerif", Font.PLAIN, 14);

    private Theme() {
    }

    // ---------- components ----------
    public static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setFont(BUTTON_FONT);
        b.setBackground(PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setBorder(new EmptyBorder(10, 20, 10, 20));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton linkButton(String text) {
        JButton b = new JButton(text);
        b.setFont(BODY_FONT);
        b.setForeground(PRIMARY);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JLabel title(String text) {
        JLabel l = new JLabel(text);
        l.setFont(TITLE_FONT);
        l.setForeground(TEXT);
        return l;
    }

    public static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(BODY_FONT);
        l.setForeground(TEXT);
        return l;
    }

    public static JLabel mutedLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(BODY_FONT);
        l.setForeground(MUTED);
        return l;
    }

    public static void styleField(JTextField f) {
        f.setFont(BODY_FONT);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(209, 213, 219)),
                new EmptyBorder(6, 8, 6, 8)));
    }

    public static void styleTable(JTable t) {
        t.setFont(BODY_FONT);
        t.setRowHeight(28);
        t.setGridColor(new Color(229, 231, 235));
        t.setSelectionBackground(new Color(219, 234, 254));
        t.setSelectionForeground(TEXT);
        t.setFillsViewportHeight(true);
        JTableHeader h = t.getTableHeader();
        h.setFont(BUTTON_FONT);
        h.setBackground(new Color(229, 231, 235));
        h.setForeground(TEXT);
    }

    // ---------- layout helpers (panel must use GridBagLayout) ----------
    public static void addRow(JPanel panel, int row, String labelText, JComponent field) {
        addRow(panel, row, label(labelText), field);
    }

    public static void addRow(JPanel panel, int row, JComponent labelComp, JComponent field) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(6, 0, 6, 14);
        panel.add(labelComp, c);

        c.gridx = 1;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(6, 0, 6, 0);
        panel.add(field, c);
    }

    public static void addFull(JPanel panel, int row, JComponent comp, int topGap) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.gridwidth = 2;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(topGap, 0, 0, 0);
        panel.add(comp, c);
    }

    // ---------- dialogs ----------
    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "CareerHub", JOptionPane.ERROR_MESSAGE);
    }

    public static void showWarning(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "CareerHub", JOptionPane.WARNING_MESSAGE);
    }

    public static void showInfo(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "CareerHub", JOptionPane.INFORMATION_MESSAGE);
    }

    // "2026-11-15 10:30:00.0" -> "2026-11-15"
    public static String dateOnly(String timestamp) {
        if (timestamp == null || timestamp.length() < 10) {
            return "";
        }
        return timestamp.substring(0, 10);
    }
}
