package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import careerhub.dao.UserDAO;
import careerhub.dao.UserDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.exception.InvalidInputException;
import careerhub.model.JobSeeker;
import careerhub.model.Resume;
import careerhub.util.ResumeManager;
import careerhub.util.Validator;

public class ProfilePanel extends JPanel {

    private final JobSeeker seeker;
    private final UserDAO userDAO = new UserDAOImpl();

    private JTextField nameField, emailField, phoneField, cityField, skillsField;
    private JLabel resumeLabel;

    public ProfilePanel(JobSeeker seeker) {
        this.seeker = seeker;
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(new EmptyBorder(25, 30, 25, 30));

        nameField = new JTextField(seeker.getFullName(), 30);
        emailField = new JTextField(seeker.getEmail(), 30);
        emailField.setEditable(false);          // email is the login id, so it can't change
        phoneField = new JTextField(seeker.getPhone(), 30);
        cityField = new JTextField(seeker.getCity(), 30);
        skillsField = new JTextField(seeker.getSkills(), 30);
        JTextField[] fields = {nameField, emailField, phoneField, cityField, skillsField};
        for (JTextField f : fields) {
            Theme.styleField(f);
        }

        resumeLabel = Theme.label("");
        refreshResumeLabel();

        JButton saveBtn = Theme.primaryButton("Save Profile");
        saveBtn.addActionListener(e -> saveProfile());

        JButton uploadBtn = Theme.primaryButton("Upload Resume");
        uploadBtn.addActionListener(e -> uploadResume());

        JButton viewBtn = Theme.primaryButton("View Resume");
        viewBtn.addActionListener(e -> viewResume());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(saveBtn);
        buttons.add(uploadBtn);
        buttons.add(viewBtn);

        Theme.addRow(card, 0, "Full name", nameField);
        Theme.addRow(card, 1, "Email", emailField);
        Theme.addRow(card, 2, "Phone", phoneField);
        Theme.addRow(card, 3, "City", cityField);
        Theme.addRow(card, 4, "Skills", skillsField);
        Theme.addRow(card, 5, "Resume", resumeLabel);
        Theme.addFull(card, 6, buttons, 20);

        add(card, BorderLayout.NORTH);
    }

    private void refreshResumeLabel() {
        Resume r = seeker.getResume();
        if (r == null) {
            resumeLabel.setText("No resume uploaded yet");
        } else {
            resumeLabel.setText(r.getFileName() + "  (" + r.getSizeInKB() + " KB)");
        }
    }

    private void saveProfile() {
        try {
            Validator.checkNotEmpty("Full name", nameField.getText());
            Validator.checkNotEmpty("Skills", skillsField.getText());

            seeker.setFullName(nameField.getText().trim());
            seeker.setPhone(phoneField.getText().trim());
            seeker.setCity(cityField.getText().trim());
            seeker.setSkills(skillsField.getText().trim());

            userDAO.updateProfile(seeker);
            Theme.showInfo(this, "Profile saved.");

        } catch (InvalidInputException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void uploadResume() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter(
                "Resume files (PDF, DOC, DOCX)", "pdf", "doc", "docx"));

        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        try {
            Resume resume = ResumeManager.saveResume(chooser.getSelectedFile(), seeker.getUserId());
            userDAO.updateResumePath(seeker.getUserId(), resume.getFilePath());
            seeker.setResume(resume);
            refreshResumeLabel();
            Theme.showInfo(this, "Resume uploaded successfully.");

        } catch (InvalidInputException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        } catch (IOException ex) {
            Theme.showError(this, "Could not read or save the file: " + ex.getMessage());
        }
    }

    private void viewResume() {
        Resume r = seeker.getResume();
        if (r == null || !r.exists()) {
            Theme.showWarning(this, "No resume found. Please upload one first.");
            return;
        }
        try {
            Desktop.getDesktop().open(new File(r.getFilePath()));
        } catch (IOException | UnsupportedOperationException ex) {
            Theme.showError(this, "Could not open the resume: " + ex.getMessage());
        }
    }
}
