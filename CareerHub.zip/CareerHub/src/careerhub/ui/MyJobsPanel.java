package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.JobDAO;
import careerhub.dao.JobDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.model.Job;
import careerhub.model.Recruiter;

public class MyJobsPanel extends JPanel {

    private final Recruiter recruiter;
    private final JobDAO jobDAO = new JobDAOImpl();

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel summaryLabel;
    private List<Job> jobs = new ArrayList<>();     // same order as table rows

    public MyJobsPanel(Recruiter recruiter) {
        this.recruiter = recruiter;
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        // ---- top bar ----
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        summaryLabel = Theme.mutedLabel("");

        JButton postBtn = Theme.primaryButton("+ Post New Job");
        postBtn.addActionListener(e -> postJob());
        JButton refreshBtn = Theme.linkButton("Refresh");
        refreshBtn.addActionListener(e -> loadJobs());

        JPanel topRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        topRight.setOpaque(false);
        topRight.add(refreshBtn);
        topRight.add(postBtn);
        top.add(summaryLabel, BorderLayout.WEST);
        top.add(topRight, BorderLayout.EAST);

        // ---- table ----
        tableModel = new DefaultTableModel(
                new String[] {"Title", "City", "Salary (Rs./year)", "Status", "Applicants", "Posted"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);
        table.getColumnModel().getColumn(3).setCellRenderer(new StatusCellRenderer());

        // ---- bottom buttons ----
        JButton editBtn = Theme.primaryButton("Edit Selected");
        editBtn.addActionListener(e -> editJob());
        JButton toggleBtn = Theme.primaryButton("Close / Reopen Selected");
        toggleBtn.addActionListener(e -> toggleStatus());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bottom.setOpaque(false);
        bottom.add(editBtn);
        bottom.add(toggleBtn);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        loadJobs();
    }

    public void loadJobs() {
        try {
            jobs = jobDAO.getJobsByRecruiter(recruiter.getUserId());
            tableModel.setRowCount(0);
            for (Job j : jobs) {
                tableModel.addRow(new Object[] {
                        j.getTitle(),
                        j.getCity(),
                        String.format("%,.0f", j.getSalary()),
                        j.getStatus(),
                        j.getApplicantCount(),
                        Theme.dateOnly(j.getPostedAt())
                });
            }
            summaryLabel.setText("You have posted " + jobs.size() + " job(s)");
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private Job getSelectedJob() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select a job from the table first.");
            return null;
        }
        return jobs.get(row);
    }

    private void postJob() {
        JobFormDialog dialog = new JobFormDialog(
                SwingUtilities.getWindowAncestor(this), recruiter, null);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            loadJobs();
        }
    }

    private void editJob() {
        Job job = getSelectedJob();
        if (job == null) {
            return;
        }
        if ("REMOVED".equals(job.getStatus())) {
            Theme.showWarning(this, "This job was removed by the admin and cannot be edited.");
            return;
        }
        JobFormDialog dialog = new JobFormDialog(
                SwingUtilities.getWindowAncestor(this), recruiter, job);
        dialog.setVisible(true);
        loadJobs();
    }

    private void toggleStatus() {
        Job job = getSelectedJob();
        if (job == null) {
            return;
        }
        if ("REMOVED".equals(job.getStatus())) {
            Theme.showWarning(this, "This job was removed by the admin and cannot be reopened.");
            return;
        }

        String newStatus = "OPEN".equals(job.getStatus()) ? "CLOSED" : "OPEN";
        int choice = JOptionPane.showConfirmDialog(this,
                "Change \"" + job.getTitle() + "\" to " + newStatus + "?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            jobDAO.updateJobStatus(job.getJobId(), newStatus);
            loadJobs();
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
