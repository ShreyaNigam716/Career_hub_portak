package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import careerhub.model.User;

// Parent of all dashboards: header with welcome text and logout
public abstract class BaseDashboard extends JFrame {

    public BaseDashboard(User user, String roleTitle) {
        setTitle("CareerHub - " + roleTitle);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 660);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(buildHeader(user, roleTitle), BorderLayout.NORTH);
    }

    private JPanel buildHeader(User user, String roleTitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.PRIMARY);
        header.setBorder(new EmptyBorder(14, 24, 14, 24));

        JLabel brand = new JLabel("CareerHub  |  " + roleTitle);
        brand.setFont(Theme.HEADING_FONT);
        brand.setForeground(Color.WHITE);

        JLabel welcome = new JLabel("Welcome, " + user.getFullName() + "   ");
        welcome.setFont(Theme.BODY_FONT);
        welcome.setForeground(Color.WHITE);

        JButton logout = new JButton("Logout");
        logout.setFocusPainted(false);
        logout.addActionListener(e -> logout());

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(welcome);
        right.add(logout);

        header.add(brand, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    protected void logout() {
        dispose();
        new LoginFrame().setVisible(true);
    }
}
