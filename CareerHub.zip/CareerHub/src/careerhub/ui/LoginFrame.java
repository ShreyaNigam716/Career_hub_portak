package careerhub.ui;

import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import careerhub.dao.UserDAO;
import careerhub.dao.UserDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.exception.InvalidInputException;
import careerhub.exception.InvalidLoginException;
import careerhub.model.User;
import careerhub.util.Validator;

public class LoginFrame extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private final UserDAO userDAO = new UserDAOImpl();

    public LoginFrame() {
        setTitle("CareerHub - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 440);
        setLocationRelativeTo(null);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.BACKGROUND);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(new EmptyBorder(30, 35, 30, 35));

        JLabel title = Theme.title("CareerHub");
        title.setForeground(Theme.PRIMARY);
        title.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel subtitle = Theme.mutedLabel("Sign in to find or post jobs");
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);

        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        Theme.styleField(emailField);
        Theme.styleField(passwordField);

        JButton loginBtn = Theme.primaryButton("Login");
        loginBtn.addActionListener(e -> doLogin());

        JButton registerBtn = Theme.linkButton("New here? Create an account");
        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterFrame().setVisible(true);
        });

        Theme.addFull(card, 0, title, 0);
        Theme.addFull(card, 1, subtitle, 4);
        Theme.addRow(card, 2, "Email", emailField);
        Theme.addRow(card, 3, "Password", passwordField);
        Theme.addFull(card, 4, loginBtn, 20);
        Theme.addFull(card, 5, registerBtn, 10);

        root.add(card);
        setContentPane(root);
        getRootPane().setDefaultButton(loginBtn);   // Enter key = Login
    }

    private void doLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());

        try {
            Validator.checkNotEmpty("Email", email);
            Validator.checkNotEmpty("Password", password);

            User user = userDAO.login(email, password);
            dispose();
            user.showDashboard();     // POLYMORPHISM: each role opens its own dashboard

        } catch (InvalidInputException | InvalidLoginException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
