package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.ApplicationDAO;
import careerhub.dao.ApplicationDAOImpl;
import careerhub.dao.JobDAO;
import careerhub.dao.JobDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.model.Applicant;
import careerhub.model.Job;
import careerhub.model.Recruiter;
import careerhub.model.Resume;

public class ApplicantsPanel extends JPanel {

    private static final int STATUS_COL = 6;

    private final Recruiter recruiter;
    private final JobDAO jobDAO = new JobDAOImpl();
    private final ApplicationDAO applicationDAO = new ApplicationDAOImpl();

    private JComboBox<Job> jobCombo;
    private JLabel summaryLabel;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Applicant> applicants = new ArrayList<>();   // same order as table rows
    private boolean loadingJobs = false;

    public ApplicantsPanel(Recruiter recruiter) {
        this.recruiter = recruiter;
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        add(buildTopBar(), BorderLayout.NORTH);
        add(buildTable(), BorderLayout.CENTER);
        add(buildButtons(), BorderLayout.SOUTH);

        loadJobs();
    }

    private JPanel buildTopBar() {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        top.setBackground(Theme.CARD);

        jobCombo = new JComboBox<>();
        jobCombo.setFont(Theme.BODY_FONT);
        jobCombo.setPreferredSize(new Dimension(480, 32));
        jobCombo.addActionListener(e -> {
            if (!loadingJobs) {
                loadApplicants();
            }
        });

        summaryLabel = Theme.mutedLabel("");

        top.add(Theme.label("Job:"));
        top.add(jobCombo);
        top.add(summaryLabel);
        return top;
    }

    private JScrollPane buildTable() {
        tableModel = new DefaultTableModel(
                new String[] {"Name", "Email", "Phone", "City", "Skills", "Applied On", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);
        table.getColumnModel().getColumn(STATUS_COL).setCellRenderer(new StatusCellRenderer());

        // Opening an applicant marks them as SEEN
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                markSelectedAsSeen();
            }
        });
        return new JScrollPane(table);
    }

    private JPanel buildButtons() {
        JButton resumeBtn = Theme.primaryButton("View Resume");
        resumeBtn.addActionListener(e -> viewResume());

        JButton shortlistBtn = Theme.primaryButton("Shortlist");
        shortlistBtn.setBackground(Theme.SUCCESS);
        shortlistBtn.addActionListener(e -> changeStatus("SHORTLISTED"));

        JButton rejectBtn = Theme.primaryButton("Reject");
        rejectBtn.setBackground(Theme.DANGER);
        rejectBtn.addActionListener(e -> changeStatus("REJECTED"));

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bottom.setOpaque(false);
        bottom.add(resumeBtn);
        bottom.add(shortlistBtn);
        bottom.add(rejectBtn);
        return bottom;
    }

    // Refills the job drop-down and keeps the current selection if possible
    public void loadJobs() {
        try {
            List<Job> jobs = jobDAO.getJobsByRecruiter(recruiter.getUserId());
            Job previous = (Job) jobCombo.getSelectedItem();

            loadingJobs = true;
            try {
                jobCombo.removeAllItems();
                Job toSelect = null;
                for (Job j : jobs) {
                    jobCombo.addItem(j);
                    if (previous != null && j.getJobId() == previous.getJobId()) {
                        toSelect = j;
                    }
                }
                if (toSelect != null) {
                    jobCombo.setSelectedItem(toSelect);
                }
            } finally {
                loadingJobs = false;
            }
            loadApplicants();

        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void loadApplicants() {
        Job job = (Job) jobCombo.getSelectedItem();
        tableModel.setRowCount(0);
        applicants = new ArrayList<>();

        if (job == null) {
            summaryLabel.setText("You have not posted any jobs yet");
            return;
        }

        try {
            applicants = applicationDAO.getApplicantsByJob(job.getJobId());
            for (Applicant a : applicants) {
                tableModel.addRow(new Object[] {
                        a.getSeekerName(),
                        a.getSeekerEmail(),
                        a.getSeekerPhone(),
                        a.getSeekerCity(),
                        a.getSeekerSkills(),
                        Theme.dateOnly(a.getAppliedAt()),
                        a.getStatus()
                });
            }
            summaryLabel.setText(applicants.size() + " applicant(s)");
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void markSelectedAsSeen() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        Applicant a = applicants.get(row);
        if (!"APPLIED".equals(a.getStatus())) {
            return;
        }
        try {
            applicationDAO.updateStatus(a.getApplicationId(), "SEEN");
            a.setStatus("SEEN");
            tableModel.setValueAt("SEEN", row, STATUS_COL);
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void changeStatus(String newStatus) {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select an applicant first.");
            return;
        }
        Applicant a = applicants.get(row);
        try {
            applicationDAO.updateStatus(a.getApplicationId(), newStatus);
            a.setStatus(newStatus);
            tableModel.setValueAt(newStatus, row, STATUS_COL);
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void viewResume() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select an applicant first.");
            return;
        }
        Resume r = applicants.get(row).getResume();
        if (r == null || !r.exists()) {
            Theme.showWarning(this, "This applicant's resume file was not found.");
            return;
        }
        try {
            Desktop.getDesktop().open(new File(r.getFilePath()));
        } catch (IOException | UnsupportedOperationException ex) {
            Theme.showError(this, "Could not open the resume: " + ex.getMessage());
        }
    }
}
