package careerhub.ui;

import java.awt.Component;
import java.awt.Font;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

// Colours a status column: green = good, red = bad, blue = seen, amber = waiting
public class StatusCellRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {

        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        setHorizontalAlignment(CENTER);
        setFont(getFont().deriveFont(Font.BOLD));

        if (!isSelected) {
            switch (String.valueOf(value)) {
                case "SHORTLISTED":
                case "OPEN":
                    setForeground(Theme.SUCCESS);
                    break;
                case "REJECTED":
                case "REMOVED":
                    setForeground(Theme.DANGER);
                    break;
                case "SEEN":
                    setForeground(Theme.PRIMARY);
                    break;
                default:                       // APPLIED, CLOSED
                    setForeground(Theme.WARNING);
            }
        }
        return this;
    }
}
