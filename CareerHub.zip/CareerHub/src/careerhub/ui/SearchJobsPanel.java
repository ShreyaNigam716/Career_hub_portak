package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.ApplicationDAO;
import careerhub.dao.ApplicationDAOImpl;
import careerhub.dao.JobDAO;
import careerhub.dao.JobDAOImpl;
import careerhub.exception.AlreadyAppliedException;
import careerhub.exception.DatabaseException;
import careerhub.exception.InvalidInputException;
import careerhub.model.Job;
import careerhub.model.JobSeeker;

public class SearchJobsPanel extends JPanel {

    private final JobSeeker seeker;
    private final JobDAO jobDAO = new JobDAOImpl();
    private final ApplicationDAO applicationDAO = new ApplicationDAOImpl();

    private JTextField titleField, cityField, salaryField;
    private JLabel countLabel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextArea detailsArea;

    // Same order as the table rows, so row number = index in this list
    private List<Job> currentJobs = new ArrayList<>();

    public SearchJobsPanel(JobSeeker seeker) {
        this.seeker = seeker;
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        add(buildFilterBar(), BorderLayout.NORTH);
        add(buildTable(), BorderLayout.CENTER);
        add(buildBottom(), BorderLayout.SOUTH);

        searchJobs();   // show all open jobs at start
    }

    private JPanel buildFilterBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        bar.setBackground(Theme.CARD);

        titleField = new JTextField(14);
        cityField = new JTextField(10);
        salaryField = new JTextField(8);
        Theme.styleField(titleField);
        Theme.styleField(cityField);
        Theme.styleField(salaryField);

        JButton searchBtn = Theme.primaryButton("Search");
        searchBtn.addActionListener(e -> searchJobs());

        JButton clearBtn = Theme.linkButton("Clear");
        clearBtn.addActionListener(e -> {
            titleField.setText("");
            cityField.setText("");
            salaryField.setText("");
            searchJobs();
        });

        countLabel = Theme.mutedLabel("");

        bar.add(Theme.label("Title"));
        bar.add(titleField);
        bar.add(Theme.label("City"));
        bar.add(cityField);
        bar.add(Theme.label("Min salary (Rs./year)"));
        bar.add(salaryField);
        bar.add(searchBtn);
        bar.add(clearBtn);
        bar.add(countLabel);
        return bar;
    }

    private JScrollPane buildTable() {
        tableModel = new DefaultTableModel(
                new String[] {"Title", "Company", "City", "Salary (Rs./year)", "Posted"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showDetails();
            }
        });
        return new JScrollPane(table);
    }

    private JPanel buildBottom() {
        JPanel bottom = new JPanel(new BorderLayout(0, 10));
        bottom.setOpaque(false);

        detailsArea = new JTextArea(6, 40);
        detailsArea.setEditable(false);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setFont(Theme.BODY_FONT);
        detailsArea.setBorder(new EmptyBorder(8, 10, 8, 10));

        JButton applyBtn = Theme.primaryButton("Apply for selected job");
        applyBtn.addActionListener(e -> applyForSelectedJob());

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonRow.setOpaque(false);
        buttonRow.add(applyBtn);

        bottom.add(new JScrollPane(detailsArea), BorderLayout.CENTER);
        bottom.add(buttonRow, BorderLayout.SOUTH);
        return bottom;
    }

    private void searchJobs() {
        try {
            double minSalary = 0;
            String salaryText = salaryField.getText().trim();
            if (!salaryText.isEmpty()) {
                try {
                    minSalary = Double.parseDouble(salaryText);
                } catch (NumberFormatException ex) {
                    throw new InvalidInputException("Salary must be a number");
                }
            }
            currentJobs = jobDAO.searchJobs(titleField.getText().trim(),
                    cityField.getText().trim(), minSalary);
            fillTable();

        } catch (InvalidInputException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void fillTable() {
        tableModel.setRowCount(0);
        for (Job j : currentJobs) {
            tableModel.addRow(new Object[] {
                    j.getTitle(),
                    j.getCompanyName(),
                    j.getCity(),
                    String.format("%,.0f", j.getSalary()),
                    Theme.dateOnly(j.getPostedAt())
            });
        }
        detailsArea.setText("");
        countLabel.setText(currentJobs.size() + " job(s) found");
    }

    private void showDetails() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        Job j = currentJobs.get(row);
        detailsArea.setText(j.getTitle() + " at " + j.getCompanyName()
                + "\nLocation: " + j.getCity()
                + "   |   Salary: Rs. " + String.format("%,.0f", j.getSalary()) + " / year"
                + "\n\n" + (j.getDescription() == null ? "" : j.getDescription()));
        detailsArea.setCaretPosition(0);
    }

    private void applyForSelectedJob() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select a job from the list first.");
            return;
        }
        if (seeker.getResume() == null) {
            Theme.showWarning(this, "Please upload your resume in the My Profile tab before applying.");
            return;
        }

        Job job = currentJobs.get(row);
        int choice = JOptionPane.showConfirmDialog(this,
                "Apply for \"" + job.getTitle() + "\" at " + job.getCompanyName() + "?",
                "Confirm application", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            applicationDAO.apply(job.getJobId(), seeker.getUserId());
            Theme.showInfo(this, "Application submitted! Track it in the My Applications tab.");
        } catch (AlreadyAppliedException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
