package careerhub.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.JobDAO;
import careerhub.dao.JobDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.model.Job;

public class ManageJobsPanel extends JPanel {

    private final JobDAO jobDAO = new JobDAOImpl();

    private DefaultTableModel tableModel;
    private JTable table;
    private JSpinner daysSpinner;
    private JLabel countLabel;
    private List<Job> jobs = new ArrayList<>();     // same order as table rows

    public ManageJobsPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        // ---- top bar ----
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        top.setBackground(Theme.CARD);
        countLabel = Theme.mutedLabel("");
        JButton refreshBtn = Theme.linkButton("Refresh");
        refreshBtn.addActionListener(e -> loadJobs());
        top.add(refreshBtn);
        top.add(countLabel);

        // ---- table ----
        tableModel = new DefaultTableModel(
                new String[] {"ID", "Title", "Company", "City", "Salary (Rs./year)",
                              "Status", "Applicants", "Posted"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);
        table.getColumnModel().getColumn(5).setCellRenderer(new StatusCellRenderer());

        // ---- bottom ----
        JButton removeBtn = Theme.primaryButton("Remove Selected Post");
        removeBtn.setBackground(Theme.DANGER);
        removeBtn.addActionListener(e -> removeSelected());

        daysSpinner = new JSpinner(new SpinnerNumberModel(30, 1, 3650, 1));
        daysSpinner.setFont(Theme.BODY_FONT);

        JButton removeOldBtn = Theme.primaryButton("Remove Posts Older Than (days):");
        removeOldBtn.setBackground(Theme.WARNING);
        removeOldBtn.addActionListener(e -> removeOld());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bottom.setOpaque(false);
        bottom.add(removeBtn);
        bottom.add(removeOldBtn);
        bottom.add(daysSpinner);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        loadJobs();
    }

    public void loadJobs() {
        try {
            jobs = jobDAO.getAllJobs();
            tableModel.setRowCount(0);
            for (Job j : jobs) {
                tableModel.addRow(new Object[] {
                        j.getJobId(),
                        j.getTitle(),
                        j.getCompanyName(),
                        j.getCity(),
                        String.format("%,.0f", j.getSalary()),
                        j.getStatus(),
                        j.getApplicantCount(),
                        Theme.dateOnly(j.getPostedAt())
                });
            }
            countLabel.setText(jobs.size() + " job post(s) in total");
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void removeSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showWarning(this, "Please select a job post first.");
            return;
        }
        Job job = jobs.get(row);
        if ("REMOVED".equals(job.getStatus())) {
            Theme.showWarning(this, "This post is already removed.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(this,
                "Remove \"" + job.getTitle() + "\" posted by " + job.getCompanyName() + "?\n"
                + "It will disappear from job search.",
                "Confirm remove", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            jobDAO.updateJobStatus(job.getJobId(), "REMOVED");
            loadJobs();
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }

    private void removeOld() {
        int days = (Integer) daysSpinner.getValue();

        int choice = JOptionPane.showConfirmDialog(this,
                "Remove every job post older than " + days + " days?",
                "Confirm remove", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int removed = jobDAO.removeOldJobs(days);
            Theme.showInfo(this, removed + " old post(s) removed.");
            loadJobs();
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
