package careerhub.ui;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import careerhub.dao.ReportDAO;
import careerhub.dao.ReportDAOImpl;
import careerhub.exception.DatabaseException;

public class ReportsPanel extends JPanel {

    private final ReportDAO reportDAO = new ReportDAOImpl();
    private DefaultTableModel tableModel;

    public ReportsPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(Theme.BACKGROUND);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(Theme.title("System Summary"), BorderLayout.WEST);
        JButton refreshBtn = Theme.primaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadReport());
        top.add(refreshBtn, BorderLayout.EAST);

        tableModel = new DefaultTableModel(new String[] {"Metric", "Count"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);
        Theme.styleTable(table);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadReport();
    }

    public void loadReport() {
        try {
            List<String[]> rows = reportDAO.getSummary();
            tableModel.setRowCount(0);
            for (String[] row : rows) {
                tableModel.addRow(row);
            }
        } catch (DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
