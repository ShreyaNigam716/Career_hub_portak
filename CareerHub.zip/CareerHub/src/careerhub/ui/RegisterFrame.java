package careerhub.ui;

import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import careerhub.dao.UserDAO;
import careerhub.dao.UserDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.exception.DuplicateUserException;
import careerhub.exception.InvalidInputException;
import careerhub.model.JobSeeker;
import careerhub.model.Recruiter;
import careerhub.model.User;
import careerhub.util.Validator;

public class RegisterFrame extends JFrame {

    private JComboBox<String> roleCombo;
    private JTextField nameField, emailField, phoneField, cityField, extraField;
    private JPasswordField passwordField, confirmField;
    private JLabel extraLabel;
    private final UserDAO userDAO = new UserDAOImpl();

    public RegisterFrame() {
        setTitle("CareerHub - Register");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.BACKGROUND);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(new EmptyBorder(25, 35, 25, 35));

        JLabel title = Theme.title("Create account");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel subtitle = Theme.mutedLabel("Admin accounts are created by the system");
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);

        roleCombo = new JComboBox<>(new String[] {"Job Seeker", "Recruiter"});
        roleCombo.setFont(Theme.BODY_FONT);
        roleCombo.addActionListener(e -> updateExtraLabel());

        nameField = new JTextField(20);
        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        confirmField = new JPasswordField(20);
        phoneField = new JTextField(20);
        cityField = new JTextField(20);
        extraField = new JTextField(20);
        JTextField[] fields = {nameField, emailField, passwordField, confirmField,
                               phoneField, cityField, extraField};
        for (JTextField f : fields) {
            Theme.styleField(f);
        }

        extraLabel = Theme.label("Skills (comma separated)");

        JButton registerBtn = Theme.primaryButton("Register");
        registerBtn.addActionListener(e -> doRegister());

        JButton backBtn = Theme.linkButton("Already have an account? Login");
        backBtn.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        Theme.addFull(card, 0, title, 0);
        Theme.addFull(card, 1, subtitle, 4);
        Theme.addRow(card, 2, "I am a", roleCombo);
        Theme.addRow(card, 3, "Full name", nameField);
        Theme.addRow(card, 4, "Email", emailField);
        Theme.addRow(card, 5, "Password", passwordField);
        Theme.addRow(card, 6, "Confirm password", confirmField);
        Theme.addRow(card, 7, "Phone", phoneField);
        Theme.addRow(card, 8, "City", cityField);
        Theme.addRow(card, 9, extraLabel, extraField);
        Theme.addFull(card, 10, registerBtn, 20);
        Theme.addFull(card, 11, backBtn, 10);

        root.add(card);
        setContentPane(root);
    }

    // The last field changes meaning with the role
    private void updateExtraLabel() {
        if (roleCombo.getSelectedIndex() == 0) {
            extraLabel.setText("Skills (comma separated)");
        } else {
            extraLabel.setText("Company name");
        }
    }

    private void doRegister() {
        boolean isSeeker = roleCombo.getSelectedIndex() == 0;

        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirm = new String(confirmField.getPassword());
        String phone = phoneField.getText().trim();
        String city = cityField.getText().trim();
        String extra = extraField.getText().trim();

        try {
            Validator.checkNotEmpty("Full name", name);
            Validator.checkEmail(email);
            Validator.checkPassword(password);
            if (!password.equals(confirm)) {
                throw new InvalidInputException("Passwords do not match");
            }
            Validator.checkNotEmpty(isSeeker ? "Skills" : "Company name", extra);

            User user;
            if (isSeeker) {
                user = new JobSeeker(0, name, email, password, phone, city, extra);
            } else {
                user = new Recruiter(0, name, email, password, phone, city, extra);
            }

            userDAO.registerUser(user);
            Theme.showInfo(this, "Account created! Please login.");
            dispose();
            new LoginFrame().setVisible(true);

        } catch (InvalidInputException | DuplicateUserException | DatabaseException ex) {
            Theme.showError(this, ex.getMessage());
        }
    }
}
