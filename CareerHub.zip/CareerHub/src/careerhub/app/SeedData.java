package careerhub.app;

import careerhub.dao.UserDAO;
import careerhub.dao.UserDAOImpl;
import careerhub.exception.DatabaseException;
import careerhub.exception.DuplicateUserException;
import careerhub.exception.InvalidInputException;
import careerhub.model.Admin;
import careerhub.model.JobSeeker;
import careerhub.model.Recruiter;
import careerhub.model.User;
import careerhub.util.Validator;

// Run once after creating the database: creates one demo account for each role.
public class SeedData {

    public static void main(String[] args) {
        UserDAO dao = new UserDAOImpl();

        seed(dao, new Admin(0, "Site Admin", "admin@careerhub.com", "admin123",
                "9999999999", "Delhi"));
        seed(dao, new Recruiter(0, "Rahul Mehta", "rahul@techcorp.com", "rec12345",
                "9888888888", "Noida", "TechCorp Pvt Ltd"));
        seed(dao, new JobSeeker(0, "Demo Seeker", "seeker@demo.com", "seeker123",
                "9777777777", "Ghaziabad", "Java, MySQL, React"));

        System.out.println("Seeding finished.");
    }

    private static void seed(UserDAO dao, User user) {
        try {
            Validator.checkEmail(user.getEmail());
            Validator.checkPassword(user.getPassword());
            dao.registerUser(user);
            System.out.println("Created: " + user);
        } catch (DuplicateUserException e) {
            System.out.println("Already exists: " + user.getEmail());
        } catch (InvalidInputException | DatabaseException e) {
            System.out.println("Could not create " + user.getEmail() + ": " + e.getMessage());
        }
    }
}
