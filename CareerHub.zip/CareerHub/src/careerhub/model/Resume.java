package careerhub.model;

import java.io.File;

public class Resume {

    private String filePath;

    public Resume(String filePath) {
        this.filePath = filePath;
    }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public String getFileName() {
        return new File(filePath).getName();
    }

    public boolean exists() {
        return new File(filePath).exists();
    }

    public long getSizeInKB() {
        return new File(filePath).length() / 1024;
    }

    @Override
    public String toString() {
        return "Resume [" + getFileName() + "]";
    }
}
