package careerhub.model;

import careerhub.ui.RecruiterDashboard;

public class Recruiter extends User {

    private String companyName;

    public Recruiter(int userId, String fullName, String email, String password,
                     String phone, String city, String companyName) {
        super(userId, fullName, email, password, phone, city);
        this.companyName = companyName;
    }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    @Override
    public String getRole() {
        return "RECRUITER";
    }

    @Override
    public void showDashboard() {
        new RecruiterDashboard(this).setVisible(true);
    }
}
