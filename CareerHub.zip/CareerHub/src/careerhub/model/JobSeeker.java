package careerhub.model;

import careerhub.ui.JobSeekerDashboard;

public class JobSeeker extends User {

    private String skills;
    private Resume resume;

    public JobSeeker(int userId, String fullName, String email, String password,
                     String phone, String city, String skills) {
        super(userId, fullName, email, password, phone, city);
        this.skills = skills;
    }

    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }

    public Resume getResume() { return resume; }
    public void setResume(Resume resume) { this.resume = resume; }

    @Override
    public String getRole() {
        return "JOB_SEEKER";
    }

    @Override
    public void showDashboard() {
        new JobSeekerDashboard(this).setVisible(true);
    }
}
