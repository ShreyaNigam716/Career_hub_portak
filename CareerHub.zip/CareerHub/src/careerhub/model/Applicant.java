package careerhub.model;

// An Application plus the details of the job seeker who made it
public class Applicant extends Application {

    private String seekerName;
    private String seekerEmail;
    private String seekerPhone;
    private String seekerCity;
    private String seekerSkills;
    private Resume resume;

    public Applicant(int applicationId, int jobId, int seekerId,
                     String status, String appliedAt) {
        super(applicationId, jobId, seekerId, status, appliedAt);
    }

    public String getSeekerName() { return seekerName; }
    public void setSeekerName(String seekerName) { this.seekerName = seekerName; }

    public String getSeekerEmail() { return seekerEmail; }
    public void setSeekerEmail(String seekerEmail) { this.seekerEmail = seekerEmail; }

    public String getSeekerPhone() { return seekerPhone; }
    public void setSeekerPhone(String seekerPhone) { this.seekerPhone = seekerPhone; }

    public String getSeekerCity() { return seekerCity; }
    public void setSeekerCity(String seekerCity) { this.seekerCity = seekerCity; }

    public String getSeekerSkills() { return seekerSkills; }
    public void setSeekerSkills(String seekerSkills) { this.seekerSkills = seekerSkills; }

    public Resume getResume() { return resume; }
    public void setResume(Resume resume) { this.resume = resume; }
}
