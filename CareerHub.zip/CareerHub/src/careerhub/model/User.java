package careerhub.model;

public abstract class User {

    private int userId;
    private String fullName;
    private String email;
    private String password;   // plain text only while registering, hash after loading from DB
    private String phone;
    private String city;

    public User(int userId, String fullName, String email, String password,
                String phone, String city) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.city = city;
    }

    // ----- getters and setters (encapsulation) -----
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    // ----- abstract methods: every role must implement these (polymorphism) -----
    public abstract String getRole();

    public abstract void showDashboard();

    @Override
    public String toString() {
        return getRole() + " [" + fullName + ", " + email + "]";
    }
}
