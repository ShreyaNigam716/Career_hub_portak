package careerhub.model;

import careerhub.ui.AdminDashboard;

public class Admin extends User {

    public Admin(int userId, String fullName, String email, String password,
                 String phone, String city) {
        super(userId, fullName, email, password, phone, city);
    }

    @Override
    public String getRole() {
        return "ADMIN";
    }

    @Override
    public void showDashboard() {
        new AdminDashboard(this).setVisible(true);
    }
}
