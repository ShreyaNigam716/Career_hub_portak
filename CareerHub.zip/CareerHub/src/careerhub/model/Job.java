package careerhub.model;

public class Job {

    private int jobId;
    private int recruiterId;
    private String title;
    private String description;
    private String city;
    private double salary;
    private String status;     // OPEN, CLOSED, REMOVED
    private String postedAt;
    private String companyName;
    private int applicantCount;

    public Job(int jobId, int recruiterId, String title, String description,
               String city, double salary, String status, String postedAt) {
        this.jobId = jobId;
        this.recruiterId = recruiterId;
        this.title = title;
        this.description = description;
        this.city = city;
        this.salary = salary;
        this.status = status;
        this.postedAt = postedAt;
    }

    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }

    public int getRecruiterId() { return recruiterId; }
    public void setRecruiterId(int recruiterId) { this.recruiterId = recruiterId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPostedAt() { return postedAt; }
    public void setPostedAt(String postedAt) { this.postedAt = postedAt; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public int getApplicantCount() { return applicantCount; }
    public void setApplicantCount(int applicantCount) { this.applicantCount = applicantCount; }

    @Override
    public String toString() {
        return title + " | " + city + " | Rs." + salary + " | " + status;
    }
}
