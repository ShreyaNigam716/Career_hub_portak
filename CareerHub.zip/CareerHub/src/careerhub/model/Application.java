package careerhub.model;

public class Application {

    private int applicationId;
    private int jobId;
    private int seekerId;
    private String status;     // APPLIED, SEEN, SHORTLISTED, REJECTED
    private String appliedAt;
    private String jobTitle;
    private String companyName;

    public Application(int applicationId, int jobId, int seekerId,
                       String status, String appliedAt) {
        this.applicationId = applicationId;
        this.jobId = jobId;
        this.seekerId = seekerId;
        this.status = status;
        this.appliedAt = appliedAt;
    }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }

    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }

    public int getSeekerId() { return seekerId; }
    public void setSeekerId(int seekerId) { this.seekerId = seekerId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAppliedAt() { return appliedAt; }
    public void setAppliedAt(String appliedAt) { this.appliedAt = appliedAt; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    @Override
    public String toString() {
        return "Application #" + applicationId + " [job " + jobId
                + ", seeker " + seekerId + ", " + status + "]";
    }
}
