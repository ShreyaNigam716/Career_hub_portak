package careerhub.exception;

public class DuplicateUserException extends Exception {
    public DuplicateUserException(String email) {
        super("An account with email " + email + " already exists");
    }
}
