package careerhub.exception;

public class EmptyFieldException extends InvalidInputException {
    public EmptyFieldException(String fieldName) {
        super(fieldName + " cannot be empty");
    }
}
