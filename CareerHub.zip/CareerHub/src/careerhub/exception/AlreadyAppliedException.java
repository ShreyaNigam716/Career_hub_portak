package careerhub.exception;

public class AlreadyAppliedException extends Exception {
    public AlreadyAppliedException() {
        super("You have already applied for this job");
    }
}
