package careerhub.dao;

import java.util.List;

import careerhub.exception.DatabaseException;
import careerhub.model.Job;

public interface JobDAO {

    // ---- job seeker ----
    // Only OPEN jobs are returned. Empty title/city match everything.
    List<Job> searchJobs(String title, String city, double minSalary)
            throws DatabaseException;

    // ---- recruiter ----
    void postJob(Job job) throws DatabaseException;

    void updateJob(Job job) throws DatabaseException;

    // status: OPEN, CLOSED or REMOVED (a REMOVED job can never change again)
    void updateJobStatus(int jobId, String status) throws DatabaseException;

    List<Job> getJobsByRecruiter(int recruiterId) throws DatabaseException;

    // ---- admin ----
    List<Job> getAllJobs() throws DatabaseException;

    // Marks every non-removed job older than 'days' as REMOVED, returns how many
    int removeOldJobs(int days) throws DatabaseException;
}
