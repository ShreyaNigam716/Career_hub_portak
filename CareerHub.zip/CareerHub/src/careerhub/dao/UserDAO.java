package careerhub.dao;

import java.util.List;

import careerhub.exception.DatabaseException;
import careerhub.exception.DuplicateUserException;
import careerhub.exception.InvalidLoginException;
import careerhub.model.JobSeeker;
import careerhub.model.User;

public interface UserDAO {

    void registerUser(User user) throws DatabaseException, DuplicateUserException;

    User login(String email, String password)
            throws InvalidLoginException, DatabaseException;

    boolean emailExists(String email) throws DatabaseException;

    // ---- job seeker profile ----
    void updateProfile(JobSeeker seeker) throws DatabaseException;

    void updateResumePath(int userId, String resumePath) throws DatabaseException;

    // ---- admin ----
    List<User> getAllUsers() throws DatabaseException;

    void deleteUser(int userId) throws DatabaseException;
}
