package careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import careerhub.db.DBConnection;
import careerhub.exception.DatabaseException;

public class ReportDAOImpl implements ReportDAO {

    @Override
    public List<String[]> getSummary() throws DatabaseException {
        String sql = "SELECT label, total FROM v_admin_summary";
        List<String[]> rows = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                rows.add(new String[] {rs.getString("label"),
                                       String.valueOf(rs.getInt("total"))});
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load report: " + e.getMessage(), e);
        }
        return rows;
    }
}
