package careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import careerhub.db.DBConnection;
import careerhub.exception.DatabaseException;
import careerhub.exception.DuplicateUserException;
import careerhub.exception.InvalidLoginException;
import careerhub.model.Admin;
import careerhub.model.JobSeeker;
import careerhub.model.Recruiter;
import careerhub.model.Resume;
import careerhub.model.User;
import careerhub.util.PasswordUtil;

public class UserDAOImpl implements UserDAO {

    @Override
    public void registerUser(User user) throws DatabaseException, DuplicateUserException {
        if (emailExists(user.getEmail())) {
            throw new DuplicateUserException(user.getEmail());
        }

        String sql = "INSERT INTO users "
                + "(full_name, email, password_hash, role, phone, city, skills, company_name) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, PasswordUtil.hashPassword(user.getPassword()));
            ps.setString(4, user.getRole());
            ps.setString(5, user.getPhone());
            ps.setString(6, user.getCity());

            // Role specific columns
            String skills = null;
            String company = null;
            if (user instanceof JobSeeker) {
                skills = ((JobSeeker) user).getSkills();
            } else if (user instanceof Recruiter) {
                company = ((Recruiter) user).getCompanyName();
            }
            ps.setString(7, skills);
            ps.setString(8, company);

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not register user: " + e.getMessage(), e);
        }
    }

    @Override
    public User login(String email, String password)
            throws InvalidLoginException, DatabaseException {

        String sql = "SELECT * FROM users WHERE email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new InvalidLoginException("Wrong email or password");
                }
                String storedHash = rs.getString("password_hash");
                if (!PasswordUtil.verify(password, storedHash)) {
                    throw new InvalidLoginException("Wrong email or password");
                }
                return buildUser(rs);
            }

        } catch (SQLException e) {
            throw new DatabaseException("Login failed: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean emailExists(String email) throws DatabaseException {
        String sql = "SELECT 1 FROM users WHERE email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not check email: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateProfile(JobSeeker seeker) throws DatabaseException {
        String sql = "UPDATE users SET full_name = ?, phone = ?, city = ?, skills = ? "
                   + "WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, seeker.getFullName());
            ps.setString(2, seeker.getPhone());
            ps.setString(3, seeker.getCity());
            ps.setString(4, seeker.getSkills());
            ps.setInt(5, seeker.getUserId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not update profile: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateResumePath(int userId, String resumePath) throws DatabaseException {
        String sql = "UPDATE users SET resume_path = ? WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, resumePath);
            ps.setInt(2, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not save resume: " + e.getMessage(), e);
        }
    }

    @Override
    public List<User> getAllUsers() throws DatabaseException {
        String sql = "SELECT * FROM users ORDER BY role, full_name";
        List<User> users = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                users.add(buildUser(rs));
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load users: " + e.getMessage(), e);
        }
        return users;
    }

    @Override
    public void deleteUser(int userId) throws DatabaseException {
        // Foreign keys use ON DELETE CASCADE, so this user's jobs/applications go too
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not delete user: " + e.getMessage(), e);
        }
    }

    // Turns one database row into the correct User subclass
    private User buildUser(ResultSet rs) throws SQLException {
        int id = rs.getInt("user_id");
        String name = rs.getString("full_name");
        String email = rs.getString("email");
        String hash = rs.getString("password_hash");
        String phone = rs.getString("phone");
        String city = rs.getString("city");
        String role = rs.getString("role");

        switch (role) {
            case "JOB_SEEKER":
                JobSeeker seeker = new JobSeeker(id, name, email, hash, phone, city,
                        rs.getString("skills"));
                String resumePath = rs.getString("resume_path");
                if (resumePath != null) {
                    seeker.setResume(new Resume(resumePath));
                }
                return seeker;
            case "RECRUITER":
                return new Recruiter(id, name, email, hash, phone, city,
                        rs.getString("company_name"));
            default:
                return new Admin(id, name, email, hash, phone, city);
        }
    }
}
