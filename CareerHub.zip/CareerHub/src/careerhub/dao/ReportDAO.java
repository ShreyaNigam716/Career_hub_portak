package careerhub.dao;

import java.util.List;

import careerhub.exception.DatabaseException;

public interface ReportDAO {

    // Each row is {label, count}
    List<String[]> getSummary() throws DatabaseException;
}
