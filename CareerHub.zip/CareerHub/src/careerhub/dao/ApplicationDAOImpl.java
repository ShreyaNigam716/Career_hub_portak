package careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import careerhub.db.DBConnection;
import careerhub.exception.AlreadyAppliedException;
import careerhub.exception.DatabaseException;
import careerhub.model.Applicant;
import careerhub.model.Application;
import careerhub.model.Resume;

public class ApplicationDAOImpl implements ApplicationDAO {

    @Override
    public void apply(int jobId, int seekerId)
            throws AlreadyAppliedException, DatabaseException {

        String sql = "INSERT INTO applications (job_id, seeker_id) VALUES (?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            ps.setInt(2, seekerId);
            ps.executeUpdate();

        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {          // duplicate (job_id, seeker_id)
                throw new AlreadyAppliedException();
            }
            // The MySQL trigger's message ("no longer open") also arrives here
            throw new DatabaseException(e.getMessage(), e);
        }
    }

    @Override
    public List<Application> getApplicationsBySeeker(int seekerId)
            throws DatabaseException {

        String sql = "SELECT a.*, j.title, u.company_name "
                   + "FROM applications a "
                   + "JOIN jobs j ON a.job_id = j.job_id "
                   + "JOIN users u ON j.recruiter_id = u.user_id "
                   + "WHERE a.seeker_id = ? ORDER BY a.applied_at DESC";

        List<Application> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, seekerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Application app = new Application(
                            rs.getInt("application_id"),
                            rs.getInt("job_id"),
                            rs.getInt("seeker_id"),
                            rs.getString("status"),
                            rs.getString("applied_at"));
                    app.setJobTitle(rs.getString("title"));
                    app.setCompanyName(rs.getString("company_name"));
                    list.add(app);
                }
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load applications: " + e.getMessage(), e);
        }
        return list;
    }

    @Override
    public List<Applicant> getApplicantsByJob(int jobId) throws DatabaseException {
        String sql = "SELECT a.*, u.full_name, u.email, u.phone, u.city, u.skills, u.resume_path "
                   + "FROM applications a JOIN users u ON a.seeker_id = u.user_id "
                   + "WHERE a.job_id = ? ORDER BY a.applied_at";

        List<Applicant> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Applicant ap = new Applicant(
                            rs.getInt("application_id"),
                            rs.getInt("job_id"),
                            rs.getInt("seeker_id"),
                            rs.getString("status"),
                            rs.getString("applied_at"));
                    ap.setSeekerName(rs.getString("full_name"));
                    ap.setSeekerEmail(rs.getString("email"));
                    ap.setSeekerPhone(rs.getString("phone"));
                    ap.setSeekerCity(rs.getString("city"));
                    ap.setSeekerSkills(rs.getString("skills"));
                    String path = rs.getString("resume_path");
                    if (path != null) {
                        ap.setResume(new Resume(path));
                    }
                    list.add(ap);
                }
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load applicants: " + e.getMessage(), e);
        }
        return list;
    }

    @Override
    public void updateStatus(int applicationId, String status) throws DatabaseException {
        String sql = "UPDATE applications SET status = ? WHERE application_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, applicationId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not update status: " + e.getMessage(), e);
        }
    }
}
