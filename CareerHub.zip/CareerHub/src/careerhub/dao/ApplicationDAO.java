package careerhub.dao;

import java.util.List;

import careerhub.exception.AlreadyAppliedException;
import careerhub.exception.DatabaseException;
import careerhub.model.Applicant;
import careerhub.model.Application;

public interface ApplicationDAO {

    // ---- job seeker ----
    void apply(int jobId, int seekerId) throws AlreadyAppliedException, DatabaseException;

    List<Application> getApplicationsBySeeker(int seekerId) throws DatabaseException;

    // ---- recruiter ----
    List<Applicant> getApplicantsByJob(int jobId) throws DatabaseException;

    // status: APPLIED, SEEN, SHORTLISTED or REJECTED
    void updateStatus(int applicationId, String status) throws DatabaseException;
}
