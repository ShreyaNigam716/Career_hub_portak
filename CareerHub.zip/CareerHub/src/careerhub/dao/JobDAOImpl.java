package careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import careerhub.db.DBConnection;
import careerhub.exception.DatabaseException;
import careerhub.model.Job;

public class JobDAOImpl implements JobDAO {

    @Override
    public List<Job> searchJobs(String title, String city, double minSalary)
            throws DatabaseException {

        String sql = "SELECT j.*, u.company_name, 0 AS applicant_count "
                   + "FROM jobs j JOIN users u ON j.recruiter_id = u.user_id "
                   + "WHERE j.status = 'OPEN' AND j.title LIKE ? AND j.city LIKE ? "
                   + "AND j.salary >= ? ORDER BY j.posted_at DESC";

        List<Job> jobs = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + title + "%");
            ps.setString(2, "%" + city + "%");
            ps.setDouble(3, minSalary);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    jobs.add(mapJob(rs));
                }
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not search jobs: " + e.getMessage(), e);
        }
        return jobs;
    }

    @Override
    public void postJob(Job job) throws DatabaseException {
        String sql = "INSERT INTO jobs (recruiter_id, title, description, city, salary, status) "
                   + "VALUES (?, ?, ?, ?, ?, 'OPEN')";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, job.getRecruiterId());
            ps.setString(2, job.getTitle());
            ps.setString(3, job.getDescription());
            ps.setString(4, job.getCity());
            ps.setDouble(5, job.getSalary());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not post job: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateJob(Job job) throws DatabaseException {
        // recruiter_id in WHERE: a recruiter can only edit their own jobs
        String sql = "UPDATE jobs SET title = ?, description = ?, city = ?, salary = ? "
                   + "WHERE job_id = ? AND recruiter_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, job.getTitle());
            ps.setString(2, job.getDescription());
            ps.setString(3, job.getCity());
            ps.setDouble(4, job.getSalary());
            ps.setInt(5, job.getJobId());
            ps.setInt(6, job.getRecruiterId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not update job: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateJobStatus(int jobId, String status) throws DatabaseException {
        String sql = "UPDATE jobs SET status = ? WHERE job_id = ? AND status <> 'REMOVED'";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, jobId);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not change job status: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Job> getJobsByRecruiter(int recruiterId) throws DatabaseException {
        String sql = "SELECT j.*, u.company_name, "
                   + "(SELECT COUNT(*) FROM applications a WHERE a.job_id = j.job_id) AS applicant_count "
                   + "FROM jobs j JOIN users u ON j.recruiter_id = u.user_id "
                   + "WHERE j.recruiter_id = ? ORDER BY j.posted_at DESC";

        List<Job> jobs = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, recruiterId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    jobs.add(mapJob(rs));
                }
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load your jobs: " + e.getMessage(), e);
        }
        return jobs;
    }

    @Override
    public List<Job> getAllJobs() throws DatabaseException {
        String sql = "SELECT j.*, u.company_name, "
                   + "(SELECT COUNT(*) FROM applications a WHERE a.job_id = j.job_id) AS applicant_count "
                   + "FROM jobs j JOIN users u ON j.recruiter_id = u.user_id "
                   + "ORDER BY j.posted_at DESC";

        List<Job> jobs = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                jobs.add(mapJob(rs));
            }

        } catch (SQLException e) {
            throw new DatabaseException("Could not load jobs: " + e.getMessage(), e);
        }
        return jobs;
    }

    @Override
    public int removeOldJobs(int days) throws DatabaseException {
        String sql = "UPDATE jobs SET status = 'REMOVED' "
                   + "WHERE status <> 'REMOVED' AND posted_at < (NOW() - INTERVAL ? DAY)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, days);
            return ps.executeUpdate();

        } catch (SQLException e) {
            throw new DatabaseException("Could not remove old jobs: " + e.getMessage(), e);
        }
    }

    private Job mapJob(ResultSet rs) throws SQLException {
        Job job = new Job(
                rs.getInt("job_id"),
                rs.getInt("recruiter_id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getString("city"),
                rs.getDouble("salary"),
                rs.getString("status"),
                rs.getString("posted_at"));
        job.setCompanyName(rs.getString("company_name"));
        job.setApplicantCount(rs.getInt("applicant_count"));
        return job;
    }
}
