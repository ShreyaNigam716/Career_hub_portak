package careerhub.util;

import careerhub.exception.EmptyFieldException;
import careerhub.exception.InvalidInputException;

public class Validator {

    private Validator() {
    }

    public static void checkNotEmpty(String fieldName, String value)
            throws EmptyFieldException {
        if (value == null || value.trim().isEmpty()) {
            throw new EmptyFieldException(fieldName);
        }
    }

    public static void checkEmail(String email) throws InvalidInputException {
        checkNotEmpty("Email", email);
        int at = email.indexOf('@');
        int dot = email.lastIndexOf('.');
        if (at < 1 || dot < at + 2 || dot == email.length() - 1) {
            throw new InvalidInputException("Please enter a valid email address");
        }
    }

    public static void checkPassword(String password) throws InvalidInputException {
        checkNotEmpty("Password", password);
        if (password.length() < 6) {
            throw new InvalidInputException("Password must be at least 6 characters");
        }
    }
}
