package careerhub.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import careerhub.exception.InvalidInputException;
import careerhub.model.Resume;

public class ResumeManager {

    private static final String RESUME_FOLDER = "resumes";
    private static final long MAX_SIZE_BYTES = 2 * 1024 * 1024;   // 2 MB

    private ResumeManager() {
    }

    public static Resume saveResume(File source, int userId)
            throws InvalidInputException, IOException {

        String name = source.getName().toLowerCase();
        if (!(name.endsWith(".pdf") || name.endsWith(".doc") || name.endsWith(".docx"))) {
            throw new InvalidInputException("Resume must be a PDF, DOC or DOCX file");
        }
        if (source.length() > MAX_SIZE_BYTES) {
            throw new InvalidInputException("Resume must be smaller than 2 MB");
        }

        File folder = new File(RESUME_FOLDER);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        File destination = new File(folder, "seeker_" + userId + "_" + source.getName());

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(destination)) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        return new Resume(destination.getPath());
    }
}
